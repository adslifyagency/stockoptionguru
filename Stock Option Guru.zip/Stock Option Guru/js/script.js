(function () {
  'use strict';

  const ctaButton = document.getElementById('join-telegram');
  if (!ctaButton || ctaButton.dataset.trackingBound === 'true') {
    return;
  }

  function trackTelegramClick(event) {
    // A middle click also opens the link. Right clicks do not.
    if (event.type === 'auxclick' && event.button !== 1) {
      return;
    }
    if (typeof window.fbq !== 'function') {
      return;
    }

    const button = event.currentTarget;
    // Preserve the existing custom event and send it only to this site's pixel.
    // This measures an outbound click, not a confirmed Telegram membership.
    try {
      window.fbq('trackSingleCustom', button.dataset.pixelId, button.dataset.pixelEvent, {
        button_id: button.id,
        button_name: 'JOIN OUR TELEGRAM',
        destination: 'Telegram',
        destination_url: button.href,
        content_category: 'Landing Page CTA'
      });
    } catch (error) {
      // Tracking failures must never prevent the native Telegram link opening.
      console.warn('Telegram click tracking was unavailable.', error);
    }
  }

  ctaButton.addEventListener('click', trackTelegramClick);
  ctaButton.addEventListener('auxclick', trackTelegramClick);
  ctaButton.dataset.trackingBound = 'true';
})();
