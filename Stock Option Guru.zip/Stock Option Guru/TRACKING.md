# Telegram button tracking

This is a static site. Upload `index.html`, `css/`, `js/`, and `images/` together to the existing host, then clear any hosting/CDN cache. No build is needed. This note does not need to be uploaded.

- Pixel ID: `1683838532843326` (unchanged).
- CTA selector: `#join-telegram`.
- Dedicated layout wrapper: `div#telegram-cta`. The wrapper has no tracking attributes or click listener; the event belongs only to the inner link.
- Custom event: `StockOptionGuruJoinButtonClick` (unchanged).
- Event parameters include `button_id: join-telegram`, `button_name: JOIN OUR TELEGRAM`, and the Telegram destination.
- Only PageView is sent on page load. The custom event is sent on CTA activation (including keyboard and middle click), scoped to the existing pixel.
- A click measures opening the Telegram link. It cannot confirm that a visitor joined the channel.

The CTA is a native link, with no delayed redirect or JavaScript popup. Its icons ignore pointer events and its hit area does not move on hover. The handler is attached directly to the link, and duplicate script initialization does not attach it twice. If Meta is blocked, the link continues to work, but tracking cannot be guaranteed.

Automatic configuration is disabled before pixel initialization. The implementation uses the same `autoConfig` and `trackSingleCustom` APIs as [Meta's official pixel template](https://github.com/facebook/GoogleTagManager-WebTemplate-For-FacebookPixel/blob/main/template.tpl). This does not establish that existing account-side Event Setup Tool rules have been removed.

## Verify after uploading

1. Open the deployed page through Test Events for this pixel in Meta Events Manager. Confirm PageView on load.
2. Click the heading, description, and empty card area: no `StockOptionGuruJoinButtonClick` should appear.
3. Click **JOIN OUR TELEGRAM** once. Check for one `StockOptionGuruJoinButtonClick` with `button_id: join-telegram` and confirm that Telegram opens the intended channel.
4. Review any existing Event Setup Tool rules. Remove obsolete URL-based or incorrectly selected click rules for this CTA, and avoid adding another rule for the same action on top of this coded event.
5. If optimizing campaigns for this click, use the preserved custom event in a custom conversion as appropriate. A manually coded event is verified in Test Events; it may not be represented by a button highlight in the Event Setup Tool. PageView is expected to remain a page-level event.

An overlay appearing in the wrong place can also be caused by saved Meta rules or the browser/extension. Local code cannot control the Meta overlay or prove event receipt in your account. Account-side verification and a live browser check are still required.

## Local checks

Run `node --check js/script.js` for JavaScript syntax. The standalone `.cjs` test file was removed at the owner's request. No testing dependencies or build tools are required for the site.

Local code checks do not establish real-browser layout or live Meta delivery. Use the deployed-page verification steps above before assessing campaign results.

## Copy

The page keeps an educational focus and avoids adding earnings promises, performance figures, fake scarcity, or testimonials. It retains a short financial-risk disclaimer. Ad approval also depends on the ad, destination content, targeting, and account requirements; copy edits alone cannot guarantee approval.
